﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mini_Market_Management_System_jj
{
    public partial class SellingForm : Form
    {
        DBC dCon = new DBC();
 
        public SellingForm()
        {
            InitializeComponent();
        }

        private void getCategory()
        {
            string selectQuerry = "SELECT * FROM CategoryTbl";
            SqlCommand command = new SqlCommand(selectQuerry, dCon.GetCon());
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            comboBox_category.DataSource = table;
            comboBox_category.ValueMember = "CatName";
            

        }

        private void getTable()
        {
            string selectQuerry = "SELECT ProdName, ProdPrice FROM ProdTbl";
            SqlCommand command = new SqlCommand(selectQuerry, dCon.GetCon());
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dataGridView_product.DataSource = table;
        }
        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void SellingForm_Load(object sender, EventArgs e)
        {
            getTable();
            getCategory();
        }

        private void button_selling_Click(object sender, EventArgs e)
        {
            SellerForm selling = new SellerForm();
            selling.Show();
            this.Hide();
        }

        private void dataGridView_product_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox_name.Text = dataGridView_product.SelectedRows[0].Cells[0].Value.ToString();
            textBox_price.Text = dataGridView_product.SelectedRows[0].Cells[1].Value.ToString();
            textBox_price.Text = dataGridView_product.SelectedRows[0].Cells[2].Value.ToString();
            textBox_qty.Text = dataGridView_product.SelectedRows[0].Cells[3].Value.ToString();
            comboBox_category.SelectedValue = dataGridView_product.SelectedRows[0].Cells[4].Value.ToString();
        }
        int grandtotal = 0, n = 0;

        private void label_kilo_Click(object sender, EventArgs e)
        {

        }

        private void button_product_Click(object sender, EventArgs e)
        {
            ProductForm product = new ProductForm();
            product.Show();
            this.Hide();
        }

        private void button_category_Click(object sender, EventArgs e)
        {
            CategoryForm category = new CategoryForm();
            category.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void button_addorder_Click_1(object sender, EventArgs e)
        {
            if (textBox_name.Text == "" || textBox_qty.Text == "")
            {
                MessageBox.Show("Missing Information", "Information Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                int Total = Convert.ToInt32(textBox_price.Text) * Convert.ToInt32(textBox_qty.Text);
                DataGridViewRow addRow = new DataGridViewRow();
                addRow.CreateCells(dataGridView_sell);
                addRow.Cells[0].Value = ++n;
                addRow.Cells[1].Value = textBox_name.Text;
                addRow.Cells[2].Value = textBox_price.Text;
                addRow.Cells[3].Value = textBox_qty.Text;
                addRow.Cells[4].Value = Total;
                dataGridView_sell.Rows.Add(addRow);
                grandtotal += Total;
                label_amount.Text = grandtotal + " PHP";
            }
        }
    }
}

        

    